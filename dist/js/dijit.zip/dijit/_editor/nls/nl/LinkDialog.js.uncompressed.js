define(
"dijit/_editor/nls/nl/LinkDialog", ({
	createLinkTitle: "Linkeigenschappen",
	insertImageTitle: "Afbeeldingseigenschappen",
	url: "URL:",
	text: "Beschrijving:",
	target: "Doel:",
	set: "Instellen",
	currentWindow: "Huidig venster",
	parentWindow: "Hoofdvenster",
	topWindow: "Bovenste venster",
	newWindow: "Nieuw venster"
})
);
