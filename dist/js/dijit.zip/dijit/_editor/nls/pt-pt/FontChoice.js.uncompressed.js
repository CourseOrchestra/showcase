define(
"dijit/_editor/nls/pt-pt/FontChoice", ({
	fontSize: "Tamanho",
	fontName: "Tipo de letra",
	formatBlock: "Formato",
	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "cursive",
	fantasy: "fantasy",
	noFormat: "Nenhum",
	p: "Parágrafo",
	h1: "Título",
	h2: "Sub-título",
	h3: "Sub-subtítulo",
	pre: "Pré-formatado",
	1: "xxs",
	2: "xs",
	3: "small",
	4: "medium",
	5: "large",
	6: "xl",
	7: "xxl"
})
);
