//>>built
define("dijit/_base/typematic",["../typematic"],function(){
});
