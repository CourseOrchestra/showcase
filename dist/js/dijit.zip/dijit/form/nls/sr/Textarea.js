//>>built
define("dijit/form/nls/sr/Textarea",{iframeEditTitle:"oblast za uređivanje",iframeFocusTitle:"okvir oblasti za uređivanje"});
