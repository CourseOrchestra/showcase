//>>built
define("dojox/calendar/nls/bg/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Днес",dayButton:"Ден",weekButton:"Седмица",fourDaysButton:"4 дни",monthButton:"Месец"});
