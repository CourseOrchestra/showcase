//>>built
define("dojox/calendar/nls/kk/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Бүгін",dayButton:"Күн",weekButton:"Апта",fourDaysButton:"4 күн",monthButton:"Ай"});
