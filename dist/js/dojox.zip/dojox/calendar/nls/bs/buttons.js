//>>built
define("dojox/calendar/nls/bs/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Danas",dayButton:"Dan",weekButton:"Sedmica",fourDaysButton:"4 dana",monthButton:"Mjesec"});
