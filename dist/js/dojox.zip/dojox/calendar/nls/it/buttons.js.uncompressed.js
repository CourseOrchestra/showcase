define( "dojox/calendar/nls/it/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Oggi",
	dayButton: "Giorno",
	weekButton: "Settimana",
	fourDaysButton: "4 Giorni",
	monthButton: "Mese"
}
);
