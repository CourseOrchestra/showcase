define( "dojox/calendar/nls/ca/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Avuí",
	dayButton: "Dia",
	weekButton: "Setmana",
	fourDaysButton: "4 dies",
	monthButton: "Mes"
}
);
