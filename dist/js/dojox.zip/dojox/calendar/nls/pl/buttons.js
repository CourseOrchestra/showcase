//>>built
define("dojox/calendar/nls/pl/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Dzisiaj",dayButton:"Dzień",weekButton:"Tydzień",fourDaysButton:"4 dni",monthButton:"Miesiąc"});
