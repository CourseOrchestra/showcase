define("dojox/calendar/nls/lt/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Šiandien",
	dayButton: "Diena",
	weekButton: "Savaitė",
	fourDaysButton: "4 dienos",
	monthButton: "Mėnuo"
});
