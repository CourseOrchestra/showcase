//>>built
define("dojox/atom/widget/nls/sr/FeedViewerEntry",{deleteButton:"[Izbriši]"});
