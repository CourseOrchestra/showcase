//>>built
define("dojox/atom/widget/nls/sr/FeedEntryEditor",{doNew:"[novo]",edit:"[uredi]",save:"[sačuvaj]",cancel:"[otkaži]"});
