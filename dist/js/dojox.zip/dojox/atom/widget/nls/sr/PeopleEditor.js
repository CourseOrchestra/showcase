//>>built
define("dojox/atom/widget/nls/sr/PeopleEditor",{add:"Dodaj",addAuthor:"Dodaj autora",addContributor:"Dodaj saradnika"});
