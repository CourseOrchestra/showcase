define(
"dojox/atom/widget/nls/it/FeedEntryViewer", ({
	displayOptions: "[visualizza opzioni]",
	title: "Titolo",
	authors: "Autori",
	contributors: "Contributor",
	id: "ID",
	close: "[chiudi]",
	updated: "Aggiornato",
	summary: "Riepilogo",
	content: "Contenuto"
})
);
