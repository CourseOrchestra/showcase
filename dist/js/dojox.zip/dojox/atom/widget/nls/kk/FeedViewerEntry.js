//>>built
define("dojox/atom/widget/nls/kk/FeedViewerEntry",({deleteButton:"[Жою]"}));
