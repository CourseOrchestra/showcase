define(
"dojox/atom/widget/nls/kk/PeopleEditor", ({
	add: "Қосу",
	addAuthor: "Авторды қосу",
	addContributor: "Салымшыны қосу"
})
);
