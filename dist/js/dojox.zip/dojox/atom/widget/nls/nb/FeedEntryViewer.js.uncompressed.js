define(
"dojox/atom/widget/nls/nb/FeedEntryViewer", ({
	displayOptions: "[visningsalternativer]",
	title: "Tittel",
	authors: "Forfattere",
	contributors: "Bidragsytere",
	id: "ID",
	close: "[lukk]",
	updated: "Oppdatert",
	summary: "Sammendrag",
	content: "Innhold"
})
);
