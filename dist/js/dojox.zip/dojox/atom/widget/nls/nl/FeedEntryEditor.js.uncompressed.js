define(
"dojox/atom/widget/nls/nl/FeedEntryEditor", ({
	doNew: "[nieuw]",
	edit: "[bewerken]",
	save: "[opslaan]",
	cancel: "[annuleren]"
})
);
