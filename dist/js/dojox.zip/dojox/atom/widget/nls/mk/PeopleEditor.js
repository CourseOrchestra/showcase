//>>built
define("dojox/atom/widget/nls/mk/PeopleEditor",{add:"Додај",addAuthor:"Додај автор",addContributor:"Додај соработник"});
