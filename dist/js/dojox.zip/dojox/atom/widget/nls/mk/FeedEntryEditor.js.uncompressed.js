define("dojox/atom/widget/nls/mk/FeedEntryEditor", {      
//begin v1.x content
	doNew: "[ново]",
	edit: "[уреди]",
	save: "[зачувај]",
	cancel: "[откажи]"
//end v1.x content
});

