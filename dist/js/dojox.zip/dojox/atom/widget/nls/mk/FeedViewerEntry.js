//>>built
define("dojox/atom/widget/nls/mk/FeedViewerEntry",{deleteButton:"[Избриши]"});
