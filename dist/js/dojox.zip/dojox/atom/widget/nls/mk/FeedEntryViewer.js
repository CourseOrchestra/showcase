//>>built
define("dojox/atom/widget/nls/mk/FeedEntryViewer",{displayOptions:"[опции за приказ]",title:"Наслов",authors:"Автори",contributors:"Соработници",id:"ИД",close:"[затвори]",updated:"Ажурирано",summary:"Резиме",content:"Содржина"});
