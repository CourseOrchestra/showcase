define("dojox/atom/widget/nls/mk/FeedEntryViewer", {      
//begin v1.x content
	displayOptions: "[опции за приказ]",
	title: "Наслов",
	authors: "Автори",
	contributors: "Соработници",
	id: "ИД",
	close: "[затвори]",
	updated: "Ажурирано",
	summary: "Резиме",
	content: "Содржина"
//end v1.x content
});

