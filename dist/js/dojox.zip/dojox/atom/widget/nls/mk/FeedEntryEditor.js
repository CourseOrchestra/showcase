//>>built
define("dojox/atom/widget/nls/mk/FeedEntryEditor",{doNew:"[ново]",edit:"[уреди]",save:"[зачувај]",cancel:"[откажи]"});
