define(
"dojox/atom/widget/nls/uk/FeedEntryEditor", ({
	doNew: "[створити]",
	edit: "[змінити]",
	save: "[зберегти]",
	cancel: "[скасувати]"
})
);
