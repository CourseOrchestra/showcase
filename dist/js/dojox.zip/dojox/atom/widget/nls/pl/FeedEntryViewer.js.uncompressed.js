define(
"dojox/atom/widget/nls/pl/FeedEntryViewer", ({
	displayOptions: "[opcje wyświetlania]",
	title: "Tytuł",
	authors: "Autorzy",
	contributors: "Kontrybutorzy",
	id: "ID",
	close: "[zamknij]",
	updated: "Zaktualizowano",
	summary: "Podsumowanie",
	content: "Treść"
})
);
