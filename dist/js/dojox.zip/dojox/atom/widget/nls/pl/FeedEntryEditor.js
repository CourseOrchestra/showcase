//>>built
define("dojox/atom/widget/nls/pl/FeedEntryEditor",({doNew:"[nowy]",edit:"[edytuj]",save:"[zapisz]",cancel:"[anuluj]"}));
