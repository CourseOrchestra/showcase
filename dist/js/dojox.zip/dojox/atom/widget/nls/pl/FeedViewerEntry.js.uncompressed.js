define(
"dojox/atom/widget/nls/pl/FeedViewerEntry", ({
	deleteButton: "[Usuń]"
})
);
