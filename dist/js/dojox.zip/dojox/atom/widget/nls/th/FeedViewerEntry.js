//>>built
define("dojox/atom/widget/nls/th/FeedViewerEntry",({deleteButton:"[ลบ]"}));
