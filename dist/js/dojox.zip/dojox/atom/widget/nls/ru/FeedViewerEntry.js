//>>built
define("dojox/atom/widget/nls/ru/FeedViewerEntry",({deleteButton:"[Удалить]"}));
