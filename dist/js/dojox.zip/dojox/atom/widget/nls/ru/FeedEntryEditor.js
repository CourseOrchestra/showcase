//>>built
define("dojox/atom/widget/nls/ru/FeedEntryEditor",({doNew:"[создать]",edit:"[изменить]",save:"[сохранить]",cancel:"[отмена]"}));
