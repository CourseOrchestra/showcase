//>>built
define("dojox/atom/widget/nls/id/FeedViewerEntry",({deleteButton:"[Hapus]"}));
