define(
"dojox/atom/widget/nls/id/FeedEntryViewer", ({
	displayOptions: "[pilihan tampilan]",
	title: "Judul",
	authors: "Penulis",
	contributors: "kontributor",
	id: "ID",
	close: "[tutup]",
	updated: "Diperbarui",
	summary: "Ringkasan",
	content: "Konten"
})
);

