//>>built
define("dojox/atom/widget/nls/id/PeopleEditor",({add:"Tambahkan",addAuthor:"Tambahkan Penulis",addContributor:"Tambahkan Kontributor"}));
