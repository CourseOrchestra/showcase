//>>built
define("dojox/atom/widget/nls/el/FeedEntryViewer",({displayOptions:"[επιλογές παρουσίασης]",title:"Τίτλος",authors:"Συντάκτες",contributors:"Συνεισφέροντες",id:"Ταυτότητα",close:"[κλείσιμο]",updated:"Ενημερώθηκε",summary:"Περίληψη",content:"Περιεχόμενο"}));
