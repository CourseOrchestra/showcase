define(
"dojox/atom/widget/nls/zh-tw/PeopleEditor", ({
	add: "新增",
	addAuthor: "新增作者",
	addContributor: "新增貢獻者"
})
);
