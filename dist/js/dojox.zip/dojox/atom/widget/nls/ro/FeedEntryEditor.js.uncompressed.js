define(
"dojox/atom/widget/nls/ro/FeedEntryEditor", ({
	doNew: "[nou]",
	edit: "[editare]",
	save: "[salvare]",
	cancel: "[anulare]"
})
);
