//>>built
define("dojox/atom/widget/nls/ro/PeopleEditor",({add:"Adăugare",addAuthor:"Adăugare autor",addContributor:"Adăugare contribuitor"}));
