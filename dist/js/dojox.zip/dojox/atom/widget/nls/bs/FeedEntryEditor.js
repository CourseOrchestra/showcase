//>>built
define("dojox/atom/widget/nls/bs/FeedEntryEditor",{doNew:"[novo]",edit:"[uredi]",save:"[sačuvaj]",cancel:"[otkaži]"});
