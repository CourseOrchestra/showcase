//>>built
define("dojox/atom/widget/nls/bs/FeedViewerEntry",{deleteButton:"[Izbriši]"});
