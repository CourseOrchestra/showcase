//>>built
define("dojox/atom/widget/nls/bs/PeopleEditor",{add:"Dodaj",addAuthor:"Dodaj autora",addContributor:"Dodaj saradnika"});
