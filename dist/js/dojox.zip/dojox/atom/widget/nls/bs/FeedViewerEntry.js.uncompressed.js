define("dojox/atom/widget/nls/bs/FeedViewerEntry", {      
//begin v1.x content
	deleteButton: "[Izbriši]"
//end v1.x content
});

