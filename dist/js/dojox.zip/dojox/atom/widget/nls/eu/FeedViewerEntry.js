//>>built
define("dojox/atom/widget/nls/eu/FeedViewerEntry",{deleteButton:"[Ezabatu]"});
