//>>built
define("dojox/atom/widget/nls/eu/FeedEntryEditor",{doNew:"[berria]",edit:"[editatu]",save:"[gorde]",cancel:"[utzi]"});
