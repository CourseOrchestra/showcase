//>>built
define("dojox/atom/widget/nls/eu/FeedEntryViewer",{displayOptions:"[bistaratu aukerak]",title:"Titulua",authors:"Autoreak",contributors:"Kolaboratzaileak",id:"IDa",close:"[itxi]",updated:"Eguneratuta",summary:"Laburpena",content:"Edukia"});
