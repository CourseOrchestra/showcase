define("dojox/atom/widget/nls/eu/FeedEntryViewer", {      
//begin v1.x content
	displayOptions: "[bistaratu aukerak]",
	title: "Titulua",
	authors: "Autoreak",
	contributors: "Kolaboratzaileak",
	id: "IDa",
	close: "[itxi]",
	updated: "Eguneratuta",
	summary: "Laburpena",
	content: "Edukia"
//end v1.x content
});

