//>>built
define("dojox/atom/widget/nls/eu/PeopleEditor",{add:"Gehitu",addAuthor:"Gehitu egilea",addContributor:"Gehitu kolaboratzailea"});
