define(
"dojox/atom/widget/nls/fi/FeedEntryViewer", ({
	displayOptions: "[näyttöasetukset]",
	title: "Otsikko",
	authors: "Tekijät",
	contributors: "Lisääjät",
	id: "Tunnus",
	close: "[sulje]",
	updated: "Päivitetty",
	summary: "Yhteenveto",
	content: "Sisältö"
})
);
