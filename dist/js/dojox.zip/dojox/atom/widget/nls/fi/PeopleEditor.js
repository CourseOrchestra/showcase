//>>built
define("dojox/atom/widget/nls/fi/PeopleEditor",({add:"Lisää",addAuthor:"Lisää tekijä",addContributor:"Lisää lisääjä"}));
