define(
"dojox/atom/widget/nls/sv/PeopleEditor", ({
	add: "Lägg till",
	addAuthor: "Lägg till författare",
	addContributor: "Lägg till medverkande"
})
);
