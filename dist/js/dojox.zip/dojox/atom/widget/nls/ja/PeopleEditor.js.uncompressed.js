define(
"dojox/atom/widget/nls/ja/PeopleEditor", ({
	add: "追加",
	addAuthor: "作成者の追加",
	addContributor: "貢献者の追加"
})
);
