//>>built
define("dojox/atom/widget/nls/pt-pt/PeopleEditor",({add:"Adicionar",addAuthor:"Adicionar autor",addContributor:"Adicionar contribuinte"}));
