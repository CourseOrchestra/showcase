//>>built
define("dojox/atom/widget/nls/pt-pt/FeedEntryEditor",({doNew:"[novo]",edit:"[editar]",save:"[guardar]",cancel:"[cancelar]"}));
