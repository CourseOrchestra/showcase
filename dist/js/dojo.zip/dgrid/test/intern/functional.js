define([
	'./functional/Keyboard',
	'./functional/KeyboardTab',
	'./functional/Selector',
	'./functional/Editor',
	'./functional/Tree'
], function () {});