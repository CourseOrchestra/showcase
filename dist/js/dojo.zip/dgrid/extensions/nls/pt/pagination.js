define({
	status: '${start} - ${end} de ${total} resultados',
	gotoFirst: 'Primeira página',
	gotoNext: 'Próxima página',
	gotoPrev: 'Página anterior',
	gotoLast: 'Última página',
	gotoPage: 'Ir para página',
	jumpPage: 'Pular para página'
});
