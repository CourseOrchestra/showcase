define(
"dojo/cldr/nls/bs/currency", //begin v1.x content
{
	"HKD_displayName": "Honkonški dolar",
	"CHF_displayName": "Švicarski franak",
	"CAD_displayName": "Kanadski dolar",
	"CNY_displayName": "Kineski juan",
	"AUD_displayName": "Australijski dolar",
	"JPY_displayName": "Japanski jen",
	"USD_displayName": "Američki dolar",
	"GBP_displayName": "Britanska funta",
	"EUR_displayName": "Euro"
}
//end v1.x content
);