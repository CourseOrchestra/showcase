/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/bs/currency",{"HKD_displayName":"Honkonški dolar","CHF_displayName":"Švicarski franak","CAD_displayName":"Kanadski dolar","CNY_displayName":"Kineski juan","AUD_displayName":"Australijski dolar","JPY_displayName":"Japanski jen","USD_displayName":"Američki dolar","GBP_displayName":"Britanska funta","EUR_displayName":"Euro"});
