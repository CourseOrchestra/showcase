define(
"dojo/cldr/nls/en-gb/currency", //begin v1.x content
{
	"USD_symbol": "$",
	"CAD_symbol": "CA$",
	"GBP_displayName": "British Pound",
	"GBP_symbol": "£",
	"HKD_symbol": "HK$",
	"AUD_symbol": "AU$",
	"CNY_symbol": "CN¥",
	"EUR_symbol": "€"
}
//end v1.x content
);