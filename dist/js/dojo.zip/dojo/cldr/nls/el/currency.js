/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/el/currency",{"HKD_displayName":"Δολάριο Χονγκ Κονγκ","CHF_displayName":"Φράγκο Ελβετίας","JPY_symbol":"JP¥","CAD_displayName":"Δολάριο Καναδά","HKD_symbol":"HK$","CNY_displayName":"Γουάν Κίνας","USD_symbol":"$","AUD_displayName":"Δολάριο Αυστραλίας","JPY_displayName":"Γιεν Ιαπωνίας","CAD_symbol":"CA$","USD_displayName":"Δολάριο ΗΠΑ","EUR_symbol":"€","CNY_symbol":"CN¥","GBP_displayName":"Λίρα Στερλίνα Βρετανίας","GBP_symbol":"£","AUD_symbol":"A$","EUR_displayName":"Ευρώ"});
